#!/usr/bin/php
<?php

/* Création du dossier de sortie */
if (!is_dir("/data/retour_images")) {
    mkdir("/data/retour_images");
}

/* Liste des images */
$images = glob("/data/*.{jpg,jpeg,png,webp,JPG,JPEG,PNG,WEBP}", GLOB_BRACE);

/* Parcours des images */
foreach ($images as $image) {

    echo "Traitement de l'image : " . basename($image) . "\n";

    /* Récupération largeur / hauteur */
    exec("identify -format \"%w %h\" " . escapeshellarg($image), $dimensions); # Escapeshellarg sert à ne pas casser la commande dans le cas où le nom de l'image contiendrait des espaces (comme si on mettait des ' au nom de l'image)
    $dimensions_sep = explode(" ", $dimensions[0]); # Explode sert à séparer les 2 valeurs qui se trouvent dans la variable dimensions en les mettant dans un autre tableau que j'ai appelé dimensions_sep
    $largeur  = $dimensions_sep[0];
    $hauteur = $dimensions_sep[1];

    /* Dimensions minimales */
    if ($largeur < 350 || $hauteur < 250) {
        echo "Les dimensions de l'image $image sont trop petites, elle ne sera pas traitée\n\n";
        continue;
    }

    /* Nom du fichier de sortie */
    $images_traitees = "/data/retour_images/" . pathinfo($image, PATHINFO_FILENAME) . ".webp"; # Pathinfo permet de récupérer le nom du fichier de l'image sans l'extension (puisqu'on la modifie)

    /* Conversion + redimensionnement SANS agrandissement */
    exec(
        "convert " .
        escapeshellarg($image) .
        " -resize 900x620\\> -strip -quality 95 " . # Le paramètre strip de convert permet de supprimer les métadonnées, ça supprime des données qui peuvent être sensibles comme les coordonnées GPS mais ça réduit aussi la taille du fichier
        escapeshellarg($images_traitees)
    );

    /* Compression progressive */
    $quality = 98;
    while (filesize($images_traitees) > 180 * 1024 && $quality > 50) {
        exec(
            "convert " .
            escapeshellarg($images_traitees) .
            " -quality $quality " .
            escapeshellarg($images_traitees)
        );
        $quality = $quality - 2;
    }

    /* Vérification finale */
    if (filesize($images_traitees) > 180 * 1024) {
        unlink($images_traitees); # Unlink permet de supprimer le fichier choisi (en l'occurence, on le fait ici car il n'est pas conforme aux attentes)
        echo "Le fichier $image est toujours trop lourd même après les traitements il a donc été supprimé\n\n";
        continue;
    }

    echo "Le traitement du fichier est terminé et il est conforme aux attentes (" . round(filesize($images_traitees)/1024) . " Ko)\n\n";
}
