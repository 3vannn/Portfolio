#!/bin/bash

Image="bigpapoo/sae103-imagick:latest"
Conteneur="docker-image"
Fichier_php="programme.php"

sudo docker pull $Image
sudo docker run -d --rm \
  --name $Conteneur \
  --entrypoint /bin/sh \
  $Image -c "tail -f /dev/null"

sudo docker exec $Conteneur mkdir -p /data


for fic in ../documents/images/*
do
    sudo docker cp $fic $Conteneur:/data/
done

sudo docker cp $Fichier_php $Conteneur:/data/
sudo docker exec $Conteneur php /data/$Fichier_php
sudo docker cp $Conteneur:/data/retour_images ./images_finales
sudo docker stop $Conteneur