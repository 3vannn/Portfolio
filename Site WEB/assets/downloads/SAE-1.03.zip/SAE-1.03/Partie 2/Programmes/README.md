Pour que le programme image fonctionne, il faut :
    - Que les images se trouve dans un dossier nommé "images"
    - Que le dossier image se trouve dans un dossier nommé "documents"
    - Que le dossier "documents" se trouve dans le dossier parent à ces programmes