/**
* @file sokoban.c
* @brief Jeu du Sokoban
* @author Evan BENOIT et Hadrien-Gaspard Le Guillou
* @version 1.0
* @date 14/12/2025
*
* Le programme reprend le jeu du Sokoban où un petit bonhomme (identifié
* ici par un '@' doit pousser des caisses sur des cibles
* respectivement '$' et '.' pour gagner la partie).
*
*/

/* Fichiers inclus */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>

/* Déclaration des constantes */
#define NB_COLONNES 12
#define NB_LIGNES 12
#define NB_DEPLACEMENTS_MAX 1000
const int ZERO=0;
const int TAILLE=12;
const int TAILLE_FICHIER=20;
const int ENLEVER=-1;
const int AJOUTER=1;
const int DOUBLE=2;
const char GAUCHE='g';
const char DROITE='d';
const char HAUT='h';
const char BAS='b';
const char SOKOBAN_GAUCHE='g';
const char SOKOBAN_DROITE='d';
const char SOKOBAN_HAUT='h';
const char SOKOBAN_BAS='b';
const char SOKOBAN_CAISSE_GAUCHE='G';
const char SOKOBAN_CAISSE_DROITE='D';
const char SOKOBAN_CAISSE_HAUT='H';
const char SOKOBAN_CAISSE_BAS='B';
const char VALIDATION='O';
const char SOKOBAN='@';
const char MUR='#';
const char RIEN=' ';
const char CAISSE='$';
const char CIBLE='.';
const char SOKOBAN_CIBLE='+';
const char CAISSE_CIBLE='*';
const char ATTENTE='\0';

typedef char t_Plateau[NB_LIGNES][NB_COLONNES];
typedef char typeDeplacements[NB_DEPLACEMENTS_MAX];

/*
* Tout au long du programme les lignes pourront être suivies d'un retour à la
* ligne et d'une indentation car elles font à elles seules plus de
* 80 caractères mais forment bien une et une execution
*/

/* Déclaration des fonctions */

/**
 * @brief Procédure principale qui gère le déroulement du jeu et son arrêt
 * @param toucheAppuyee Touche saisie par l'utilisateur
 * @param plateau Plateau du jeu
 * @param fichier Nom du fichier de la partie
 * @param ligSok Ligne actuelle de Sokoban
 * @param colSok Colonne actuelle de Sokoban
 * @param nbDepla Pointeur vers le nombre de déplacements effectués
 * @param deplacements Structure contenant l'historique des déplacements
 * @param nbDeplaFichier Nombre de déplacements chargés depuis le fichier
 * @param incrTableau Pointeur vers l'indice courant du tableau de déplacements
 */
void jeu(char toucheAppuyee, t_Plateau plateau,
    char fichier[], int ligSok, int colSok, int *nbDepla,
    typeDeplacements deplacements, int nbDeplaFichier, int *incrTableau);


/**
 * @brief Affiche le plateau de jeu à l'écran
 * @param plateau Plateau du jeu à afficher
 */
void afficher_plateau(t_Plateau plateau);


/**
 * @brief Charge une partie à partir d'un fichier
 * @param plateau Plateau du jeu à remplir
 * @param fichier Nom du fichier à charger
 */
void charger_partie(t_Plateau plateau, char fichier[]);


/**
 * @brief Enregistre l'état actuel de la partie dans un fichier
 * @param plateau Plateau du jeu à sauvegarder
 * @param fichier Nom du fichier de sauvegarde
 */
void enregistrer_partie(t_Plateau plateau, char fichier[]);


/**
 * @brief Affiche l'en-tête du jeu avec les informations essentielles
 * @param nbDepla Nombre de déplacements effectués
 * @param nomFich Nom du fichier de la partie
 */
void affichier_entete(int nbDepla, char nomFich[]);


/**
 * @brief Gère les déplacements du joueur en fonction de la touche appuyée
 * @param plateau Plateau du jeu
 * @param ligSok Pointeur vers la ligne actuelle de Sokoban
 * @param colSok Pointeur vers la colonne actuelle de Sokoban
 * @param deplacement Touche de déplacement saisie
 * @param nbDepla Pointeur vers le nombre de déplacements effectués
 */
void deplacer(t_Plateau plateau, int *ligSok, int *colSok,
    char deplacement, int *nbDepla);


/**
 * @brief Met à jour les coordonnées de Sokoban
 * @param nvLig Nouvelle ligne de Sokoban
 * @param nvCol Nouvelle colonne de Sokoban
 * @param ligSok Pointeur vers la ligne actuelle de Sokoban
 * @param colSok Pointeur vers la colonne actuelle de Sokoban
 * @param nbDepla Pointeur vers le nombre de déplacements effectués
 */
void deplacement_sokoban(int nvLig, int nvCol, int *ligSok,
    int *colSok, int *nbDepla);


/**
 * @brief Déplace Sokoban sur une case vide
 * @param plateau Plateau du jeu
 * @param ligSok Pointeur vers la ligne actuelle de Sokoban
 * @param colSok Pointeur vers la colonne actuelle de Sokoban
 * @param incrLigSok Incrément de ligne du déplacement
 * @param incrColSok Incrément de colonne du déplacement
 * @param nbDepla Pointeur vers le nombre de déplacements effectués
 */
void deplacement_rien(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int *nbDepla);


/**
 * @brief Déplace Sokoban en poussant une caisse
 * @param plateau Plateau du jeu
 * @param ligSok Pointeur vers la ligne actuelle de Sokoban
 * @param colSok Pointeur vers la colonne actuelle de Sokoban
 * @param incrLigSok Incrément de ligne du déplacement
 * @param incrColSok Incrément de colonne du déplacement
 * @param doubleIncrLigSok Incrément de ligne après la caisse
 * @param doubleIncrColSok Incrément de colonne après la caisse
 * @param nbDepla Pointeur vers le nombre de déplacements effectués
 */
void deplacement_caisse(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int doubleIncrLigSok,
    int doubleIncrColSok, int *nbDepla);


/**
 * @brief Déplace Sokoban en poussant une caisse sur une cible
 * @param plateau Plateau du jeu
 * @param ligSok Pointeur vers la ligne actuelle de Sokoban
 * @param colSok Pointeur vers la colonne actuelle de Sokoban
 * @param incrLigSok Incrément de ligne du déplacement
 * @param incrColSok Incrément de colonne du déplacement
 * @param doubleIncrLigSok Incrément de ligne après la caisse
 * @param doubleIncrColSok Incrément de colonne après la caisse
 * @param nbDepla Pointeur vers le nombre de déplacements effectués
 */
void deplacement_caisse_cible(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int doubleIncrLigSok,
    int doubleIncrColSok, int *nbDepla);


/**
 * @brief Déplace Sokoban sur une cible
 * @param plateau Plateau du jeu
 * @param ligSok Pointeur vers la ligne actuelle de Sokoban
 * @param colSok Pointeur vers la colonne actuelle de Sokoban
 * @param incrLigSok Incrément de ligne du déplacement
 * @param incrColSok Incrément de colonne du déplacement
 * @param nbDepla Pointeur vers le nombre de déplacements effectués
 */
void deplacement_cible(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int *nbDepla);


/**
 * @brief Détermine le prochain déplacement à effectuer
 * @param plateau Plateau du jeu
 * @param deplacements Historique des déplacements
 * @param nbDepla Nombre de déplacements effectués
 * @param ligSok Ligne actuelle de Sokoban
 * @param colSok Colonne actuelle de Sokoban
 * @return Caractère correspondant au déplacement
 */
char obtenir_deplacements(t_Plateau plateau, typeDeplacements deplacements,
    int nbDepla, int ligSok, int colSok);


/**
 * @brief Charge les déplacements depuis un fichier
 * @param t Structure contenant les déplacements
 * @param fichier Nom du fichier
 * @param nb Pointeur vers le nombre de déplacements chargés
 */
void charger_deplacements(typeDeplacements t, char fichier[], int *nb);


/**
 * @brief Enregistre les déplacements dans un fichier
 * @param t Tableau des déplacements
 * @param nb Nombre de déplacements
 * @param fic Nom du fichier
 */
void enregistrer_deplacements(char t[], int nb, char fic[]);


/**
 * @brief Récupère les coordonnées de Sokoban sur le plateau
 * @param plateau Plateau du jeu
 * @param ligneSok Pointeur vers la ligne de Sokoban
 * @param colonneSok Pointeur vers la colonne de Sokoban
 */
void obtenir_coord_sok(t_Plateau plateau, int *ligneSok, int *colonneSok);


/**
 * @brief Optimise une suite de déplacements en supprimant les redondances
 * @param depla Historique des déplacements
 * @param fichierPlateau Fichier du plateau de jeu
 * @param nbDeplaMax Nombre maximal de déplacements
 * @param plateauDeJeu Plateau du jeu
 * @param ligSok Ligne actuelle de Sokoban
 * @param colSok Colonne actuelle de Sokoban
 * @param t Caractère du déplacement courant
 * @param deplaOpti Tableau recevant les déplacements optimisés
 * @return Nombre de déplacements optimisés
 */
int deplacement_optimise(typeDeplacements depla, char fichierPlateau[],
    int nbDeplaMax, t_Plateau plateauDeJeu, int ligSok, int colSok,
    char t, char deplaOpti[]);


/**
 * @brief Indique si la partie est gagnée
 * @param plateauDeJeu Plateau du jeu
 * @return true si la partie est gagnée, false sinon
 */
bool gagne(t_Plateau plateauDeJeu);


int main(){
    t_Plateau plateauDeJeu; // Plateau du jeu
    typeDeplacements deplacementsFichier;
    char nomFichierPlateau[TAILLE_FICHIER],
    nomFichierDeplacements[TAILLE_FICHIER], touche=ATTENTE;
    int nbDeplacements=ZERO, ligneSokoban, colonneSokoban,
    nombreDeplacementsFichier, nbValOpti;
    int incrementationTableauDepla=0;
    char deplacementsOpti[NB_DEPLACEMENTS_MAX];
    printf("Entrez le nom du fichier du plateau : ");
    scanf("%s", nomFichierPlateau);
    charger_partie(plateauDeJeu, nomFichierPlateau);
    printf("Entrez le nom du fichier de déplacements : ");
    scanf("%s", nomFichierDeplacements);
    charger_deplacements(deplacementsFichier, nomFichierDeplacements,
        &nombreDeplacementsFichier);
    affichier_entete(nbDeplacements,nomFichierPlateau);
    afficher_plateau(plateauDeJeu);
    // Définition des coordonnées où se trouve Sokoban
    obtenir_coord_sok(plateauDeJeu, &ligneSokoban, &colonneSokoban);
    jeu(touche, plateauDeJeu, nomFichierPlateau, ligneSokoban,
        colonneSokoban, &nbDeplacements, deplacementsFichier,
        nombreDeplacementsFichier, &incrementationTableauDepla);
    // Dit si le joueur a gagné ou abandonné en fonction de la dernirèe touche
    if(gagne(plateauDeJeu)){
        printf("La suite %s est bien une solution pour le tableau %s\n",
            nomFichierDeplacements, nomFichierPlateau);
        printf("\nElle contient initialement %d caractères.", nbDeplacements);
        nbValOpti = deplacement_optimise(deplacementsFichier,
            nomFichierPlateau, nombreDeplacementsFichier, plateauDeJeu,
            ligneSokoban, colonneSokoban, touche, deplacementsOpti);

        if (nbValOpti != nombreDeplacementsFichier){
            printf("\nAprès optimisation elle contient %d ", nbValOpti);
            printf("caractères. Souhaitez-vous l'enregistrer (O/N) ? ");
            scanf(" %c", &touche);
            if (touche == VALIDATION){
                printf("\nQuel nom voulez vous donner au fichier ? ");
                scanf("%s", nomFichierDeplacements);
                enregistrer_deplacements(deplacementsOpti, nbValOpti,
                    nomFichierDeplacements);
            }
        } else {
            printf("\nAprès l'optimisation elle contient toujours ");
            printf("%d caractères. Elle est donc déjà optimisée.", nbValOpti);
        }
        
    } else {
        printf("La suite de déplacements %s N'EST ", nomFichierDeplacements);
        printf("PAS une solution pour la partie %s\n", nomFichierPlateau);
    }
    printf("\n");
    return EXIT_SUCCESS;
}

void obtenir_coord_sok(t_Plateau plateau, int *ligneSok, int *colonneSok){
    for (int i = 0 ; i < NB_LIGNES ; i++) {
        for(int j = 0 ; j < NB_COLONNES ; j++) {
            if(plateau[i][j] == SOKOBAN || plateau[i][j] ==
                SOKOBAN_CIBLE) {

                *ligneSok = i;
                *colonneSok = j;
            }
        }
    }
}

int deplacement_optimise(typeDeplacements depla, char fichierPlateau[],
    int nbDeplaMax, t_Plateau plateauDeJeu, int ligneSokoban,
    int colonneSokoban, char tApp, char deplaOpti[]) {

    int deplaTemp[nbDeplaMax][2];
    char deplaTempLet[nbDeplaMax], dernierDepla;
    int nbVal = 0, nbDeplaFinal = 0, nbDepla = 0, annule = 0, dejaVu = -1;
    charger_partie(plateauDeJeu, fichierPlateau);
    obtenir_coord_sok(plateauDeJeu, &ligneSokoban, &colonneSokoban);
    for (int i = 0 ; i < nbDeplaMax ; i++) {
        tApp = obtenir_deplacements(plateauDeJeu, depla, nbDepla,
            ligneSokoban, colonneSokoban);

        deplacer(plateauDeJeu, &ligneSokoban, &colonneSokoban,
            tApp, &nbDepla);

        if (toupper(tApp) == depla[nbDepla - 1]) {
            for (int j = 0 ; j < nbVal ; j++) {
                deplaOpti[nbDeplaFinal] = deplaTempLet[j];
                nbDeplaFinal++;
            }
            deplaOpti[nbDeplaFinal] = toupper(tApp);
            nbDeplaFinal++;
            nbVal = ZERO;
        } else {
            annule = ZERO;
            if (nbVal > 0) {
                dernierDepla = deplaTempLet[nbVal - 1];
                if ((dernierDepla == HAUT && tApp == BAS) || 
                    (dernierDepla == BAS && tApp == HAUT) ||
                    (dernierDepla == GAUCHE && tApp == DROITE) || 
                    (dernierDepla == DROITE && tApp == GAUCHE)) {
                    nbVal--;
                    annule = AJOUTER;
                }
            }
            if (annule == 0) {
                dejaVu = ENLEVER;
                for (int j = 0 ; j < nbVal ; j++) {
                    if (deplaTemp[j][0] == ligneSokoban && 
                        deplaTemp[j][1] == colonneSokoban) {
                        dejaVu = j;
                    }
                }
                if (dejaVu >= 0) {
                    nbVal = dejaVu;
                }
                deplaTemp[nbVal][0] = ligneSokoban;
                deplaTemp[nbVal][1] = colonneSokoban;
                deplaTempLet[nbVal] = tApp;
                nbVal++;
            }
        }
    }
    for (int j = 0 ; j < nbVal ; j++) {
        deplaOpti[nbDeplaFinal] = deplaTempLet[j];
        nbDeplaFinal++;
    }
    return nbDeplaFinal;
}

void jeu(char toucheAppuyee, t_Plateau plateau, 
    char fichier[], int ligSok, int colSok, int *nbDepla,
    typeDeplacements deplacements, int nbDeplaFichier, int * incrTableau){
    
    // Boucle du jeu qui se termine si le joueur gagne ou abandonne
    while (*incrTableau < nbDeplaFichier){
        toucheAppuyee = obtenir_deplacements(plateau, deplacements,
            *incrTableau, ligSok, colSok);
        deplacer(plateau, &ligSok, &colSok, toucheAppuyee, *&nbDepla);
        system("clear");
        affichier_entete(*nbDepla, fichier);
        afficher_plateau(plateau);
        *incrTableau = *incrTableau+1;
        usleep(250000);
    }
}

void affichier_entete(int nbDepla, char nomFich[]){
    // Affiche tous les éléments de l'en-tête
    printf("\nPartie : %s     Nombre de déplacements : %d\n\n",
        nomFich, nbDepla);
}

void afficher_plateau(t_Plateau plateau){
    for(int i = ZERO ; i < TAILLE ; i++) {
        for(int j = ZERO ; j < TAILLE ; j++){
            if(plateau[i][j] == SOKOBAN_CIBLE) {
                printf("%c", SOKOBAN);
            } else if (plateau[i][j] == CAISSE_CIBLE) {
                printf("%c", CAISSE);
            } else {
                printf("%c", plateau[i][j]);
            }
        }
        printf("\n");
    }
}

char obtenir_deplacements(t_Plateau plateau, typeDeplacements deplacements,
    int nbDepla, int ligSok, int colSok){

    char depla;
    int incrLigSok = ligSok, incrColSok = colSok;
    if ((deplacements[nbDepla] == SOKOBAN_HAUT) || (deplacements[nbDepla] ==
        SOKOBAN_CAISSE_HAUT)){

            incrLigSok = ligSok - 1;
    } else if ((deplacements[nbDepla] == SOKOBAN_BAS) ||
        (deplacements[nbDepla] == SOKOBAN_CAISSE_BAS)){

            incrLigSok = ligSok + 1;
    } else if ((deplacements[nbDepla] == SOKOBAN_DROITE) ||
        (deplacements[nbDepla] == SOKOBAN_CAISSE_DROITE)){

            incrColSok=colSok+1;
    } else if ((deplacements[nbDepla] == SOKOBAN_GAUCHE) ||
        (deplacements[nbDepla] == SOKOBAN_CAISSE_GAUCHE)){

            incrColSok=colSok - 1;
    }

    if (((deplacements[nbDepla] == SOKOBAN_HAUT) &&
        ((plateau[incrLigSok][incrColSok] == RIEN) ||
        (plateau[incrLigSok][incrColSok] == CIBLE))) ||
        ((deplacements[nbDepla] == SOKOBAN_CAISSE_HAUT) &&
        ((plateau[incrLigSok][incrColSok] == CAISSE) ||
        (plateau[incrLigSok][incrColSok] == CAISSE_CIBLE)))){

                depla = HAUT;
    } else if (((deplacements[nbDepla] == SOKOBAN_BAS) &&
        ((plateau[incrLigSok][incrColSok] == RIEN) ||
        (plateau[incrLigSok][incrColSok] == CIBLE))) || 
        ((deplacements[nbDepla] == SOKOBAN_CAISSE_BAS) &&
        ((plateau[incrLigSok][incrColSok] == CAISSE) ||
        (plateau[incrLigSok][incrColSok] == CAISSE_CIBLE)))){

            depla = BAS;
    } else if (((deplacements[nbDepla] == SOKOBAN_GAUCHE) &&
        ((plateau[incrLigSok][incrColSok] == RIEN) ||
        (plateau[incrLigSok][incrColSok] == CIBLE))) ||
        ((deplacements[nbDepla] == SOKOBAN_CAISSE_GAUCHE) &&
        ((plateau[incrLigSok][incrColSok] == CAISSE) ||
        (plateau[incrLigSok][incrColSok] == CAISSE_CIBLE)))){
            
            depla = GAUCHE;
    } else if (((deplacements[nbDepla] == SOKOBAN_DROITE) &&
        ((plateau[incrLigSok][incrColSok] == RIEN) ||
        (plateau[incrLigSok][incrColSok] == CIBLE))) ||
        ((deplacements[nbDepla] == SOKOBAN_CAISSE_DROITE) &&
        ((plateau[incrLigSok][incrColSok] == CAISSE) ||
        (plateau[incrLigSok][incrColSok] == CAISSE_CIBLE)))){
            
            depla = DROITE;
    }
    return depla;
}

void deplacer(t_Plateau plateau, int *ligSok, int *colSok,
    char deplacement, int *nbDepla){

    int incrLigSok = ZERO, incrColSok = ZERO, doubleIncrLigSok = ZERO,
    doubleIncrColSok = ZERO;
    // incrLigSok et incrColSok changent en fonction de la direction choisie
    if(deplacement == HAUT) {
        incrLigSok = ENLEVER;
    } else if (deplacement == BAS) {
        incrLigSok = AJOUTER;
    } else if (deplacement == GAUCHE) {
        incrColSok = ENLEVER;
    } else if (deplacement == DROITE) {
        incrColSok = AJOUTER;
    }
    // doubleIncrLigSok et doubleIncrColSok représentent la ligne/colonne
    // plus loin
    doubleIncrLigSok = incrLigSok * DOUBLE;
    doubleIncrColSok = incrColSok * DOUBLE;
    // Le déplacement se fait en fonction du cas dans lequel le joueur
    // se trouve
    if(plateau[*ligSok + incrLigSok][*colSok + incrColSok] == RIEN){
        deplacement_rien(plateau, &*ligSok, &*colSok, incrLigSok,
            incrColSok, &*nbDepla);
    } else if (plateau[*ligSok + incrLigSok][*colSok + incrColSok] == CAISSE) {
        deplacement_caisse(plateau, &*ligSok, &*colSok, incrLigSok,
            incrColSok, doubleIncrLigSok, doubleIncrColSok, &*nbDepla);
    } else if (plateau[*ligSok + incrLigSok][*colSok + incrColSok]
        == CAISSE_CIBLE) {
        deplacement_caisse_cible(plateau, &*ligSok, &*colSok, incrLigSok,
            incrColSok, doubleIncrLigSok, doubleIncrColSok, &*nbDepla);
    } else if (plateau[*ligSok + incrLigSok][*colSok + incrColSok] == CIBLE) {
        deplacement_cible(plateau, &*ligSok, &*colSok, incrLigSok,
            incrColSok, &*nbDepla);
    }
}

void deplacement_rien(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int *nbDepla){

    // Si Sokoban se trouve sur une cible
    if (plateau[*ligSok][*colSok] == SOKOBAN_CIBLE){
        plateau[*ligSok][*colSok] = CIBLE;
        plateau[*ligSok + incrLigSok][*colSok + incrColSok] = SOKOBAN;
        deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
            &*colSok, &*nbDepla);
    } else {
        plateau[*ligSok][*colSok] = RIEN;
        plateau[*ligSok + incrLigSok][*colSok + incrColSok] = SOKOBAN;
        deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
            &*colSok, &*nbDepla);
    }
}

void deplacement_caisse(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int doubleIncrLigSok,
    int doubleIncrColSok, int *nbDepla){
    
    // Si 2 cases plus loin il ne se trouve rien
    if (plateau[*ligSok + doubleIncrLigSok][*colSok + doubleIncrColSok] ==
        RIEN){
        // Si Sokoban se trouve sur une cible
        if (plateau[*ligSok][*colSok] == SOKOBAN_CIBLE){
            plateau[*ligSok + doubleIncrLigSok]
            [*colSok + doubleIncrColSok] = CAISSE;

            plateau[*ligSok + incrLigSok][*colSok + incrColSok] = SOKOBAN;
            plateau[*ligSok][*colSok] = CIBLE;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        } else {
            plateau[*ligSok + doubleIncrLigSok]
            [*colSok + doubleIncrColSok] = CAISSE;

            plateau[*ligSok + incrLigSok][*colSok + incrColSok] = SOKOBAN;
            plateau[*ligSok][*colSok] = RIEN;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        }
    // Sinon si 2 cases plus loin il se trouve une cible
    } else if (plateau[*ligSok + doubleIncrLigSok]
        [*colSok + doubleIncrColSok] == CIBLE) {

        // Si Sokoban se trouve sur une cible
        if (plateau[*ligSok][*colSok] == SOKOBAN_CIBLE){
            plateau[*ligSok + doubleIncrLigSok]
            [*colSok + doubleIncrColSok] = CAISSE_CIBLE;

            plateau[*ligSok + incrLigSok][*colSok + incrColSok] = SOKOBAN;
            plateau[*ligSok][*colSok] = CIBLE;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        } else {
            plateau[*ligSok + doubleIncrLigSok]
            [*colSok + doubleIncrColSok] = CAISSE_CIBLE;

            plateau[*ligSok + incrLigSok][*colSok + incrColSok] = SOKOBAN;
            plateau[*ligSok][*colSok] = RIEN;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        }
    }
}

void deplacement_caisse_cible(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int doubleIncrLigSok,
    int doubleIncrColSok, int *nbDepla){

    // Si 2 cases plus loin il ne se trouve rien
    if (plateau[*ligSok + doubleIncrLigSok][*colSok + doubleIncrColSok] ==
        RIEN){
        // Si Sokoban se trouve sur une cible
        if (plateau[*ligSok][*colSok]==SOKOBAN_CIBLE){
            plateau[*ligSok + doubleIncrLigSok]
            [*colSok + doubleIncrColSok] = CAISSE;

            plateau[*ligSok + incrLigSok][*colSok + incrColSok] =
                SOKOBAN_CIBLE;

            plateau[*ligSok][*colSok] = CIBLE;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        } else {
            plateau[*ligSok + doubleIncrLigSok]
            [*colSok + doubleIncrColSok] = CAISSE;
            plateau[*ligSok + incrLigSok][*colSok + incrColSok] =
                SOKOBAN_CIBLE;

            plateau[*ligSok][*colSok] = RIEN;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        }
    // Sinon si 2 cases plus loin il se trouve une cible
    } else if (plateau[*ligSok + doubleIncrLigSok]
        [*colSok + doubleIncrColSok] == CIBLE) {
        // Si Sokoban se trouve sur une cible
        if (plateau[*ligSok][*colSok] == SOKOBAN_CIBLE){
            plateau[*ligSok + doubleIncrLigSok]
            [*colSok + doubleIncrColSok] = CAISSE_CIBLE;

            plateau[*ligSok + incrLigSok][*colSok + incrColSok] =
                SOKOBAN_CIBLE;

            plateau[*ligSok][*colSok] = CIBLE;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        } else {
            plateau[*ligSok + doubleIncrLigSok]
            [*colSok + doubleIncrColSok] = CAISSE_CIBLE;

            plateau[*ligSok + incrLigSok][*colSok + incrColSok] =
                SOKOBAN_CIBLE;
            
            plateau[*ligSok][*colSok] = RIEN;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        }
    }
}

void deplacement_cible(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int *nbDepla){

    // Si Sokoban se trouve sur une cible
    if (plateau[*ligSok][*colSok] == SOKOBAN_CIBLE){
        plateau[*ligSok][*colSok] = CIBLE;
        plateau[*ligSok + incrLigSok][*colSok + incrColSok] = SOKOBAN_CIBLE;
        deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
            &*colSok, &*nbDepla);
    } else {
        plateau[*ligSok][*colSok] = RIEN;
        plateau[*ligSok + incrLigSok][*colSok + incrColSok] = SOKOBAN_CIBLE;
        deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
            &*colSok, &*nbDepla);
    }
}

void deplacement_sokoban(int nvLig, int nvCol, int *ligSok,
    int *colSok, int *nbDepla){
    
    // Effectue les changements dans les coordonnées de Sokoban
    *ligSok = *ligSok + nvLig;
    *colSok = *colSok + nvCol;
    *nbDepla = *nbDepla + 1;
}

bool gagne(t_Plateau plateauDeJeu){
    bool victoire = true;
    // Regarde si il reste des caisses ou Sokoban sur une cible
    for (int i = 0 ; i < NB_LIGNES ; i++){
        for (int j = 0 ; j < NB_COLONNES ; j++){
            if (plateauDeJeu[i][j] == CAISSE ||
                plateauDeJeu[i][j] == SOKOBAN_CIBLE){
                    victoire = false;
            }
        }
    }
    return victoire;
}


void charger_partie(t_Plateau plateau, char fichier[]){
    FILE * f;
    char finDeLigne;

    f = fopen(fichier, "r");
    if (f==NULL){
        printf("ERREUR SUR FICHIER");
        exit(EXIT_FAILURE);
    } else {
        for (int ligne=0 ; ligne<TAILLE ; ligne++){
            for (int colonne=0 ; colonne<TAILLE ; colonne++){
                fread(&plateau[ligne][colonne], sizeof(char), 1, f);
            }
            fread(&finDeLigne, sizeof(char), 1, f);
        }
        fclose(f);
    }
}

void charger_deplacements(typeDeplacements t, char fichier[], int * nb){
    FILE * f;
    char dep;
    *nb = 0;

    f = fopen(fichier, "r");
    if (f==NULL){
        printf("FICHIER NON TROUVE\n");
    } else {
        fread(&dep, sizeof(char), 1, f);
        if (feof(f)){
            printf("FICHIER VIDE\n");
        } else {
            while (!feof(f)){
                t[*nb] = dep;
                (*nb)++;
                fread(&dep, sizeof(char), 1, f);
            }
        }
    }
    fclose(f);
}

void enregistrer_deplacements(char t[], int nb, char fic[]){
    FILE * f;

    f = fopen(fic, "w");
    fwrite(t,sizeof(char), nb, f);
    fclose(f);
}