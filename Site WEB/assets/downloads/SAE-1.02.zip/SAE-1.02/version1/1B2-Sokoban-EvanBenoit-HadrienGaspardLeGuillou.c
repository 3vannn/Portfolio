/**
* @file sokoban.c
* @brief Jeu du Sokoban
* @author Evan BENOIT et Hadrien-Gaspard Le Guillou
* @version 1.0
* @date 14/12/2025
*
* Le programme reprend le jeu du Sokoban où un petit bonhomme (identifié
* ici par un '@' doit pousser des caisses sur des cibles
* respectivement '$' et '.' pour gagner la partie).
*
*/

/* Fichiers inclus */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>

/* Déclaration des constantes */
#define NB_COLONNES 12
#define NB_LIGNES 12
#define NB_DEPLACEMENTS_MAX 1000
const int ZERO=0;
const int TAILLE=12;
const int TAILLE_FICHIER=20;
const int ENLEVER=-1;
const int AJOUTER=1;
const int DOUBLE=2;
const char GAUCHE='q';
const char DROITE='d';
const char HAUT='z';
const char BAS='s';
const char SOKOBAN_GAUCHE='g';
const char SOKOBAN_DROITE='d';
const char SOKOBAN_HAUT='h';
const char SOKOBAN_BAS='b';
const char SOKOBAN_CAISSE_GAUCHE='G';
const char SOKOBAN_CAISSE_DROITE='D';
const char SOKOBAN_CAISSE_HAUT='H';
const char SOKOBAN_CAISSE_BAS='B';
const char VALIDATION='O';
const char SOKOBAN='@';
const char MUR='#';
const char RIEN=' ';
const char CAISSE='$';
const char CIBLE='.';
const char SOKOBAN_CIBLE='+';
const char CAISSE_CIBLE='*';
const char ATTENTE='\0';

typedef char t_Plateau[NB_LIGNES][NB_COLONNES];
typedef char typeDeplacements[NB_DEPLACEMENTS_MAX];

/*
* Tout au long du programme les lignes pourront être suivies d'un retour à la
* ligne et d'une indentation car elles font à elles seules plus de
* 80 caractères mais forment bien une et une execution
*/

/* Déclaration des fonctions */

/**
 * @brief Procédure principale qui gère le déroulement du jeu et son arrêt
 * @param toucheAppuyee Touche saisie par l'utilisateur
 * @param plateau Plateau du jeu
 * @param fichier Nom du fichier de la partie
 * @param ligSok Ligne actuelle de Sokoban
 * @param colSok Colonne actuelle de Sokoban
 * @param nbDepla Pointeur vers le nombre de déplacements effectués
 * @param deplacements Structure contenant l'historique des déplacements
 * @param nbDeplaFichier Nombre de déplacements chargés depuis le fichier
 * @param incrTableau Pointeur vers l'indice courant du tableau de déplacements
 */
void jeu(char toucheAppuyee, t_Plateau plateau, 
    char fichier[], int ligSok, int colSok, int *nbDepla,
    typeDeplacements deplacements, int nbDeplaFichier, int * incrTableau);


/**
 * @brief Affiche le plateau de jeu à l'écran
 * @param plateau Plateau du jeu à afficher
 */
void afficher_plateau(t_Plateau plateau);


/**
 * @brief Charge une partie à partir d'un fichier
 * @param plateau Plateau du jeu à remplir
 * @param fichier Nom du fichier à charger
 */
void charger_partie(t_Plateau plateau, char fichier[]);


/**
 * @brief Enregistre l'état actuel de la partie dans un fichier
 * @param plateau Plateau du jeu à sauvegarder
 * @param fichier Nom du fichier de sauvegarde
 */
void enregistrer_partie(t_Plateau plateau, char fichier[]);


/**
 * @brief Affiche l'en-tête du jeu avec les informations essentielles
 * @param nbDepla Nombre de déplacements effectués
 * @param nomFich Nom du fichier de la partie
 */
void affichier_entete(int nbDepla, char nomFich[]);


/**
 * @brief Gère les déplacements du joueur en fonction de la touche appuyée
 * @param plateau Plateau du jeu
 * @param ligSok Pointeur vers la ligne actuelle de Sokoban
 * @param colSok Pointeur vers la colonne actuelle de Sokoban
 * @param deplacement Touche de déplacement saisie
 * @param nbDepla Pointeur vers le nombre de déplacements effectués
 */
void deplacer(t_Plateau plateau, int *ligSok, int *colSok,
    char deplacement, int *nbDepla);


/**
 * @brief Met à jour les coordonnées de Sokoban
 * @param nvLig Nouvelle ligne de Sokoban
 * @param nvCol Nouvelle colonne de Sokoban
 * @param ligSok Pointeur vers la ligne actuelle de Sokoban
 * @param colSok Pointeur vers la colonne actuelle de Sokoban
 * @param nbDepla Pointeur vers le nombre de déplacements effectués
 */
void deplacement_sokoban(int nvLig, int nvCol, int *ligSok,
    int *colSok, int *nbDepla);

/**
 * @brief Déplace Sokoban sur une case vide
 * @param plateau Plateau du jeu
 * @param ligSok Pointeur vers la ligne actuelle de Sokoban
 * @param colSok Pointeur vers la colonne actuelle de Sokoban
 * @param incrLigSok Incrément de ligne du déplacement
 * @param incrColSok Incrément de colonne du déplacement
 * @param nbDepla Pointeur vers le nombre de déplacements effectués
 */
void deplacement_rien(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int *nbDepla);


/**
 * @brief Déplace Sokoban en poussant une caisse
 * @param plateau Plateau du jeu
 * @param ligSok Pointeur vers la ligne actuelle de Sokoban
 * @param colSok Pointeur vers la colonne actuelle de Sokoban
 * @param incrLigSok Incrément de ligne du déplacement
 * @param incrColSok Incrément de colonne du déplacement
 * @param doubleIncrLigSok Incrément de ligne de la case située après la caisse
 * @param doubleIncrColSok Incrément de colonne de la case située après la caisse
 * @param nbDepla Pointeur vers le nombre de déplacements effectués
 */
void deplacement_caisse(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int doubleIncrLigSok,
    int doubleIncrColSok, int *nbDepla);


/**
 * @brief Déplace Sokoban en poussant une caisse sur une cible
 * @param plateau Plateau du jeu
 * @param ligSok Pointeur vers la ligne actuelle de Sokoban
 * @param colSok Pointeur vers la colonne actuelle de Sokoban
 * @param incrLigSok Incrément de ligne du déplacement
 * @param incrColSok Incrément de colonne du déplacement
 * @param doubleIncrLigSok Incrément de ligne de la case après la caisse
 * @param doubleIncrColSok Incrément de colonne de la case après la caisse
 * @param nbDepla Pointeur vers le nombre de déplacements effectués
 */
void deplacement_caisse_cible(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int doubleIncrLigSok,
    int doubleIncrColSok, int *nbDepla);


/**
 * @brief Déplace Sokoban sur une cible
 * @param plateau Plateau du jeu
 * @param ligSok Pointeur vers la ligne actuelle de Sokoban
 * @param colSok Pointeur vers la colonne actuelle de Sokoban
 * @param incrLigSok Incrément de ligne du déplacement
 * @param incrColSok Incrément de colonne du déplacement
 * @param nbDepla Pointeur vers le nombre de déplacements effectués
 */
void deplacement_cible(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int *nbDepla);


/**
 * @brief Détermine le prochain déplacement à effectuer
 * @param plateau Plateau du jeu
 * @param deplacements Historique des déplacements
 * @param nbDepla Nombre de déplacements effectués
 * @param ligSok Ligne actuelle de Sokoban
 * @param colSok Colonne actuelle de Sokoban
 * @return Caractère correspondant au déplacement
 */
char obtenir_deplacements(t_Plateau plateau, typeDeplacements deplacements,
    int nbDepla, int ligSok, int colSok);


/**
 * @brief Charge les déplacements depuis un fichier
 * @param t Structure contenant les déplacements
 * @param fichier Nom du fichier à charger
 * @param nb Pointeur vers le nombre de déplacements chargés
 */
void charger_deplacements(typeDeplacements t, char fichier[], int * nb);


/**
 * @brief Fonction qui renvoie si le joueur a gagné
 * @param plateauDeJeu Plateau du jeu de type t_Plateau
 * @return true si le joueur a gagné sinon False
 */
bool gagne(t_Plateau plateauDeJeu);

int main(){
    t_Plateau plateauDeJeu; // Plateau du jeu
    typeDeplacements deplacementsFichier;
    char nomFichierPlateau[TAILLE_FICHIER],
    nomFichierDeplacements[TAILLE_FICHIER], touche=ATTENTE;
    int nbDeplacements=ZERO, ligneSokoban, colonneSokoban,
    nombreDeplacementsFichier;
    int incrementationTableauDepla=0;
    printf("Entrez le nom du fichier du plateau : ");
    scanf("%s", nomFichierPlateau);
    printf("Entrez le nom du fichier de déplacements : ");
    scanf("%s", nomFichierDeplacements);
    charger_partie(plateauDeJeu, nomFichierPlateau);
    charger_deplacements(deplacementsFichier, nomFichierDeplacements,
        &nombreDeplacementsFichier);
    affichier_entete(nbDeplacements,nomFichierPlateau);
    afficher_plateau(plateauDeJeu);
    // Définition des coordonnées où se trouve Sokoban
    for (int i = 0 ; i < NB_LIGNES ; i++) {
        for(int j = 0 ; j < NB_COLONNES ; j++) {
            if(plateauDeJeu[i][j] == SOKOBAN || plateauDeJeu[i][j] ==
                SOKOBAN_CIBLE) {

                ligneSokoban = i;
                colonneSokoban = j;
            }
        }
    }
    jeu(touche, plateauDeJeu, nomFichierPlateau, ligneSokoban,
        colonneSokoban, &nbDeplacements, deplacementsFichier,
        nombreDeplacementsFichier, &incrementationTableauDepla);
    // Dit si le joueur a gagné ou abandonné en fonction de la dernirèe touche
    if(gagne(plateauDeJeu)){
        printf("La suite de déplacements %s est bien une solution pour la partie %s\n",
            nomFichierDeplacements, nomFichierPlateau);
        printf("Elle contient %d mouvements\n", nbDeplacements);
    } else {
        printf("La suite de déplacements %s N'EST PAS une solution pour la partie %s\n",
            nomFichierDeplacements, nomFichierPlateau);
    }
    return EXIT_SUCCESS;
}

void jeu(char toucheAppuyee, t_Plateau plateau, 
    char fichier[], int ligSok, int colSok, int *nbDepla,
    typeDeplacements deplacements, int nbDeplaFichier, int * incrTableau){
    
    // Boucle du jeu qui se termine si le joueur gagne ou abandonne
    while (*incrTableau < nbDeplaFichier){
        toucheAppuyee = obtenir_deplacements(plateau, deplacements,
            *incrTableau, ligSok, colSok);
        deplacer(plateau, &ligSok, &colSok, toucheAppuyee, *&nbDepla);
        system("clear");
        affichier_entete(*nbDepla, fichier);
        afficher_plateau(plateau);
        *incrTableau = *incrTableau+1;
        usleep(250000);
    }
}

void affichier_entete(int nbDepla, char nomFich[]){
    // Affiche tous les éléments de l'en-tête
    printf("\nPartie : %s     Nombre de déplacements : %d\n\n",
        nomFich, nbDepla);
}

void afficher_plateau(t_Plateau plateau){
    for(int i = ZERO ; i < TAILLE ; i++) {
        for(int j = ZERO ; j < TAILLE ; j++){
            if(plateau[i][j] == SOKOBAN_CIBLE) {
                printf("%c", SOKOBAN);
            } else if (plateau[i][j] == CAISSE_CIBLE) {
                printf("%c", CAISSE);
            } else {
                printf("%c", plateau[i][j]);
            }
        }
        printf("\n");
    }
}

char obtenir_deplacements(t_Plateau plateau, typeDeplacements deplacements,
    int nbDepla, int ligSok, int colSok){

    char depla;
    int incrLigSok = ligSok, incrColSok = colSok;
    if ((deplacements[nbDepla] == SOKOBAN_HAUT) || (deplacements[nbDepla] ==
        SOKOBAN_CAISSE_HAUT)){

            incrLigSok = ligSok - 1;
    } else if ((deplacements[nbDepla] == SOKOBAN_BAS) ||
        (deplacements[nbDepla] == SOKOBAN_CAISSE_BAS)){

            incrLigSok = ligSok + 1;
    } else if ((deplacements[nbDepla] == SOKOBAN_DROITE) ||
        (deplacements[nbDepla] == SOKOBAN_CAISSE_DROITE)){

            incrColSok=colSok+1;
    } else if ((deplacements[nbDepla] == SOKOBAN_GAUCHE) ||
        (deplacements[nbDepla] == SOKOBAN_CAISSE_GAUCHE)){

            incrColSok=colSok - 1;
    }

    if (((deplacements[nbDepla] == SOKOBAN_HAUT) &&
        ((plateau[incrLigSok][incrColSok] == RIEN) ||
        (plateau[incrLigSok][incrColSok] == CIBLE))) ||
        ((deplacements[nbDepla] == SOKOBAN_CAISSE_HAUT) &&
        ((plateau[incrLigSok][incrColSok] == CAISSE) ||
        (plateau[incrLigSok][incrColSok] == CAISSE_CIBLE)))){

                depla = HAUT;
    } else if (((deplacements[nbDepla] == SOKOBAN_BAS) &&
        ((plateau[incrLigSok][incrColSok] == RIEN) ||
        (plateau[incrLigSok][incrColSok] == CIBLE))) || 
        ((deplacements[nbDepla] == SOKOBAN_CAISSE_BAS) &&
        ((plateau[incrLigSok][incrColSok] == CAISSE) ||
        (plateau[incrLigSok][incrColSok] == CAISSE_CIBLE)))){

            depla = BAS;
    } else if (((deplacements[nbDepla] == SOKOBAN_GAUCHE) &&
        ((plateau[incrLigSok][incrColSok] == RIEN) ||
        (plateau[incrLigSok][incrColSok] == CIBLE))) ||
        ((deplacements[nbDepla] == SOKOBAN_CAISSE_GAUCHE) &&
        ((plateau[incrLigSok][incrColSok] == CAISSE) ||
        (plateau[incrLigSok][incrColSok] == CAISSE_CIBLE)))){
            
            depla = GAUCHE;
    } else if (((deplacements[nbDepla] == SOKOBAN_DROITE) &&
        ((plateau[incrLigSok][incrColSok] == RIEN) ||
        (plateau[incrLigSok][incrColSok] == CIBLE))) ||
        ((deplacements[nbDepla] == SOKOBAN_CAISSE_DROITE) &&
        ((plateau[incrLigSok][incrColSok] == CAISSE) ||
        (plateau[incrLigSok][incrColSok] == CAISSE_CIBLE)))){
            
            depla = DROITE;
    }
    return depla;
}

void deplacer(t_Plateau plateau, int *ligSok, int *colSok,
    char deplacement, int *nbDepla){

    int incrLigSok = ZERO, incrColSok = ZERO, doubleIncrLigSok = ZERO,
    doubleIncrColSok = ZERO;
    // incrLigSok et incrColSok changent en fonction de la direction choisie
    if(deplacement == HAUT) {
        incrLigSok = ENLEVER;
    } else if (deplacement == BAS) {
        incrLigSok = AJOUTER;
    } else if (deplacement == GAUCHE) {
        incrColSok = ENLEVER;
    } else if (deplacement == DROITE) {
        incrColSok = AJOUTER;
    }
    // doubleIncrLigSok et doubleIncrColSok représentent la ligne/colonne
    // plus loin
    doubleIncrLigSok = incrLigSok * DOUBLE;
    doubleIncrColSok = incrColSok * DOUBLE;
    // Le déplacement se fait en fonction du cas dans lequel le joueur
    // se trouve
    if(plateau[*ligSok + incrLigSok][*colSok + incrColSok] == RIEN){
        deplacement_rien(plateau, &*ligSok, &*colSok, incrLigSok,
            incrColSok, &*nbDepla);
    } else if (plateau[*ligSok + incrLigSok][*colSok + incrColSok] == CAISSE) {
        deplacement_caisse(plateau, &*ligSok, &*colSok, incrLigSok,
            incrColSok, doubleIncrLigSok, doubleIncrColSok, &*nbDepla);
    } else if (plateau[*ligSok + incrLigSok][*colSok + incrColSok]
        == CAISSE_CIBLE) {
        deplacement_caisse_cible(plateau, &*ligSok, &*colSok, incrLigSok,
            incrColSok, doubleIncrLigSok, doubleIncrColSok, &*nbDepla);
    } else if (plateau[*ligSok + incrLigSok][*colSok + incrColSok] == CIBLE) {
        deplacement_cible(plateau, &*ligSok, &*colSok, incrLigSok,
            incrColSok, &*nbDepla);
    }
}

void deplacement_rien(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int *nbDepla){

    // Si Sokoban se trouve sur une cible
    if (plateau[*ligSok][*colSok] == SOKOBAN_CIBLE){
        plateau[*ligSok][*colSok] = CIBLE;
        plateau[*ligSok + incrLigSok][*colSok + incrColSok] = SOKOBAN;
        deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
            &*colSok, &*nbDepla);
    } else {
        plateau[*ligSok][*colSok] = RIEN;
        plateau[*ligSok + incrLigSok][*colSok + incrColSok] = SOKOBAN;
        deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
            &*colSok, &*nbDepla);
    }
}

void deplacement_caisse(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int doubleIncrLigSok,
    int doubleIncrColSok, int *nbDepla){
    
    // Si 2 cases plus loin il ne se trouve rien
    if (plateau[*ligSok + doubleIncrLigSok][*colSok + doubleIncrColSok] ==
        RIEN){
        // Si Sokoban se trouve sur une cible
        if (plateau[*ligSok][*colSok] == SOKOBAN_CIBLE){
            plateau[*ligSok + doubleIncrLigSok]
            [*colSok + doubleIncrColSok] = CAISSE;

            plateau[*ligSok + incrLigSok][*colSok + incrColSok] = SOKOBAN;
            plateau[*ligSok][*colSok] = CIBLE;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        } else {
            plateau[*ligSok + doubleIncrLigSok]
            [*colSok + doubleIncrColSok] = CAISSE;

            plateau[*ligSok + incrLigSok][*colSok + incrColSok] = SOKOBAN;
            plateau[*ligSok][*colSok] = RIEN;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        }
    // Sinon si 2 cases plus loin il se trouve une cible
    } else if (plateau[*ligSok + doubleIncrLigSok]
        [*colSok + doubleIncrColSok] == CIBLE) {

        // Si Sokoban se trouve sur une cible
        if (plateau[*ligSok][*colSok] == SOKOBAN_CIBLE){
            plateau[*ligSok + doubleIncrLigSok]
            [*colSok + doubleIncrColSok] = CAISSE_CIBLE;

            plateau[*ligSok + incrLigSok][*colSok + incrColSok] = SOKOBAN;
            plateau[*ligSok][*colSok] = CIBLE;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        } else {
            plateau[*ligSok + doubleIncrLigSok]
            [*colSok + doubleIncrColSok] = CAISSE_CIBLE;

            plateau[*ligSok + incrLigSok][*colSok + incrColSok] = SOKOBAN;
            plateau[*ligSok][*colSok] = RIEN;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        }
    }
}

void deplacement_caisse_cible(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int doubleIncrLigSok,
    int doubleIncrColSok, int *nbDepla){

    // Si 2 cases plus loin il ne se trouve rien
    if (plateau[*ligSok + doubleIncrLigSok][*colSok + doubleIncrColSok] ==
        RIEN){
        // Si Sokoban se trouve sur une cible
        if (plateau[*ligSok][*colSok]==SOKOBAN_CIBLE){
            plateau[*ligSok + doubleIncrLigSok]
            [*colSok + doubleIncrColSok] = CAISSE;

            plateau[*ligSok + incrLigSok][*colSok + incrColSok] =
                SOKOBAN_CIBLE;

            plateau[*ligSok][*colSok] = CIBLE;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        } else {
            plateau[*ligSok + doubleIncrLigSok]
            [*colSok + doubleIncrColSok] = CAISSE;
            plateau[*ligSok + incrLigSok][*colSok + incrColSok] =
                SOKOBAN_CIBLE;

            plateau[*ligSok][*colSok] = RIEN;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        }
    // Sinon si 2 cases plus loin il se trouve une cible
    } else if (plateau[*ligSok + doubleIncrLigSok]
        [*colSok + doubleIncrColSok] == CIBLE) {
        // Si Sokoban se trouve sur une cible
        if (plateau[*ligSok][*colSok] == SOKOBAN_CIBLE){
            plateau[*ligSok + doubleIncrLigSok]
            [*colSok + doubleIncrColSok] = CAISSE_CIBLE;

            plateau[*ligSok + incrLigSok][*colSok + incrColSok] =
                SOKOBAN_CIBLE;

            plateau[*ligSok][*colSok] = CIBLE;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        } else {
            plateau[*ligSok + doubleIncrLigSok]
            [*colSok + doubleIncrColSok] = CAISSE_CIBLE;

            plateau[*ligSok + incrLigSok][*colSok + incrColSok] =
                SOKOBAN_CIBLE;
            
            plateau[*ligSok][*colSok] = RIEN;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        }
    }
}

void deplacement_cible(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int *nbDepla){

    // Si Sokoban se trouve sur une cible
    if (plateau[*ligSok][*colSok] == SOKOBAN_CIBLE){
        plateau[*ligSok][*colSok] = CIBLE;
        plateau[*ligSok + incrLigSok][*colSok + incrColSok] = SOKOBAN_CIBLE;
        deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
            &*colSok, &*nbDepla);
    } else {
        plateau[*ligSok][*colSok] = RIEN;
        plateau[*ligSok + incrLigSok][*colSok + incrColSok] = SOKOBAN_CIBLE;
        deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
            &*colSok, &*nbDepla);
    }
}

void deplacement_sokoban(int nvLig, int nvCol, int *ligSok,
    int *colSok, int *nbDepla){
    
    // Effectue les changements dans les coordonnées de Sokoban
    *ligSok = *ligSok + nvLig;
    *colSok = *colSok + nvCol;
    *nbDepla = *nbDepla + 1;
}

bool gagne(t_Plateau plateauDeJeu){
    bool victoire = true;
    // Regarde si il reste des caisses ou Sokoban sur une cible
    for (int i = 0 ; i < NB_LIGNES ; i++){
        for (int j = 0 ; j < NB_COLONNES ; j++){
            if (plateauDeJeu[i][j] == CAISSE ||
                plateauDeJeu[i][j] == SOKOBAN_CIBLE){
                    victoire = false;
            }
        }
    }
    return victoire;
}


void charger_partie(t_Plateau plateau, char fichier[]){
    FILE * f;
    char finDeLigne;

    f = fopen(fichier, "r");
    if (f==NULL){
        printf("ERREUR SUR FICHIER");
        exit(EXIT_FAILURE);
    } else {
        for (int ligne=0 ; ligne<TAILLE ; ligne++){
            for (int colonne=0 ; colonne<TAILLE ; colonne++){
                fread(&plateau[ligne][colonne], sizeof(char), 1, f);
            }
            fread(&finDeLigne, sizeof(char), 1, f);
        }
        fclose(f);
    }
}

void charger_deplacements(typeDeplacements t, char fichier[], int * nb){
    FILE * f;
    char dep;
    *nb = 0;

    f = fopen(fichier, "r");
    if (f==NULL){
        printf("FICHIER NON TROUVE\n");
    } else {
        fread(&dep, sizeof(char), 1, f);
        if (feof(f)){
            printf("FICHIER VIDE\n");
        } else {
            while (!feof(f)){
                t[*nb] = dep;
                (*nb)++;
                fread(&dep, sizeof(char), 1, f);
            }
        }
    }
    fclose(f);
}