/**
* @file sokoban.c
* @brief Jeu du Sokoban
* @author Evan BENOIT
* @version 1.0
* @date 8/11/2025
*
* Le programme reprend le jeu du Sokoban où un petit bonhomme (identifié
* ici par un '@' doit pousser des caisses sur des cibles
* respectivement '$' et '.' pour gagner la partie).
*
*/

/* Fichiers inclus */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>

/* Déclaration des constantes */
#define NB_COLONNES 12
#define NB_LIGNES 12
const int ZERO=0;
const int TAILLE=12;
const int TAILLE_FICHIER=20;
const int ENLEVER=-1;
const int AJOUTER=1;
const int DOUBLE=2;
const char ARRETER='x';
const char RECOMMENCER='r';
const char GAUCHE='q';
const char DROITE='d';
const char HAUT='z';
const char BAS='s';
const char VALIDATION='O';
const char SOKOBAN='@';
const char MUR='#';
const char RIEN=' ';
const char CAISSE='$';
const char CIBLE='.';
const char SOKOBAN_CIBLE='+';
const char CAISSE_CIBLE='*';
const char ATTENTE='\0';

typedef char t_Plateau[NB_LIGNES][NB_COLONNES];

/*
* Tout au long du programme les lignes pourront être suivies d'un retour à la
* ligne et d'une indentation car elles font à elles seules plus de
* 80 caractères mais forment bien une et une execution
*/

/* Déclaration des fonctions */
/**
 * @brief Procédure qui fait tourner le jeu et l'arrête
 * @param toucheAppuyee Touche que l'utilisateur a saisi de type char
 * @param plateau Plateau du jeu de type t_Plateau
 * @param fichier Nom du fichier du jeu de type char[]
 * @param ligSok Ligne où se trouve Sokoban de type int
 * @param colSok Colonne où se trouve Sokoban de type int
 * @param nbDepla Nombre de déplacements effectués de type int
 */
void jeu(char *toucheAppuyee, t_Plateau plateau, 
    char fichier[], int ligSok, int colSok, int nbDepla);

/**
 * @brief Procédure qui affiche le plateau de jeu
 * @param plateau Plateau du jeu de type t_Plateau
 */
void afficher_plateau(t_Plateau plateau);

/**
 * @brief Charge le plateau à partir du nom du fichier choisi
 * @param plateau Plateau du jeu de type t_Plateau
 * @param fichier Nom du fichier de type char[]
 */
void charger_partie(t_Plateau plateau, char fichier[]);

/**
 * @brief Procédure qui enregistre la partie
 * @param plateau Plateau du jeu de type t_Plateau
 * @param fichier Nom du fichier de type char[]
 */
void enregistrer_partie(t_Plateau plateau, char fichier[]);

/**
 * @brief Procédure affiche les informations nécessaires dans l'en-tête
 * @param nbDepla Nombre de déplacements déjà effectués de type int
 * @param nomFich Nom du fichier de type char[]
 */
void affichier_entete(int nbDepla, char nomFich[]);

/**
 * @brief Procédure qui permet de regrouper toutes les procédures de déplacements
          et de choisir où il va aller en fonction de la touche appuyée
 * @param plateau Plateau du jeu de type t_Plateau
 * @param ligSok Ligne où se trouve Sokoban de type int
 * @param colSok Colonne où se trouve Sokoban de type int
 * @param deplacement Touche sur laquelle le joueur a appuyé de type char
 * @param nbDepla Nombre de déplacements déjà effectués de type int
 */
void deplacer(t_Plateau plateau, int *ligSok, int *colSok,
    char deplacement, int *nbDepla);

/**
 * @brief Procédure qui permet de changer les coordonnées de Sokoban
 * @param nvLig Nouvelle ligne sur laquelle Sokoban va se déplacer de type int
 * @param nvCol Nouvelle colonne sur laquelle Sokoban va se déplacer de type int
 * @param ligSok Nouvelle coordonnéees de la ligne sur laquelle Sokoban va se déplacer de type int
 * @param colSok Nouvelle coordonnéees de la colonne sur laquelle Sokoban va se déplacer de type int
 * @param nbDepla Nombre de déplacements déjà effectués de type int
 */
void deplacement_sokoban(int nvLig, int nvCol, int *ligSok,
    int *colSok, int *nbDepla);

/**
 * @brief Procédure qui permet au joueur de recommencer la partie du fichier d'origine
 * @param plateau Plateau du jeu de type t_Plateau
 * @param nomFichier Nom du fichier du jeu de type char[]
 * @param ligneSokoban Ligne où se trouve Sokoban de type int
 * @param colonneSokoban Colonne où se trouve Sokoban de type int
 */
void recommencer(int *nbDepla, t_Plateau plateauDeJeu, char nomFichier[],
    int *ligneSokoban, int *colonneSokoban);

/**
 * @brief Procédure qui permet au joueur d'abandonner et d'enregistrer
 * @param plateau Plateau du jeu de type t_Plateau
 */
void abandon(t_Plateau plateauDeJeu);

/**
 * @brief Procédure qui permet de déplacer Sokoban si il n'a rien autour
 * @param plateau Plateau du jeu de type t_Plateau
 * @param ligSok Ligne où se trouve Sokoban de type int
 * @param colSok Colonne où se trouve Sokoban de type int
 * @param incrLigSok Nouvelle ligne sur laquelle Sokoban va se déplacer de type int
 * @param incrColSok Nouvelle colonne sur laquelle Sokoban va se déplacer de type int
 * @param nbDepla Nombre de déplacements déjà effectués de type int
 */
void deplacement_rien(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int *nbDepla);

/**
 * @brief Procédure qui permet de déplacer Sokoban une caisse
 * @param plateau Plateau du jeu de type t_Plateau
 * @param ligSok Ligne où se trouve Sokoban de type int
 * @param colSok Colonne où se trouve Sokoban de type int
 * @param incrLigSok Nouvelle ligne sur laquelle Sokoban va se déplacer de type int
 * @param incrColSok Nouvelle colonne sur laquelle Sokoban va se déplacer de type int
 * @param doubleIncrLigSok Ligne qui se trouve 2 ligne plus loin d'où va sokoban de type int
 * @param doubleIncrColSok Ligne qui se trouve 2 colonne plus loin d'où va sokoban de type int
 * @param nbDepla Nombre de déplacements déjà effectués de type int
 */
void deplacement_caisse(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int doubleIncrLigSok,
    int doubleIncrColSok, int *nbDepla);

/**
 * @brief Procédure qui permet de déplacer Sokoban et une caisse sur une cible
 * @param plateau Plateau du jeu de type t_Plateau
 * @param ligSok Ligne où se trouve Sokoban de type int
 * @param colSok Colonne où se trouve Sokoban de type int
 * @param incrLigSok Nouvelle ligne sur laquelle Sokoban va se déplacer de type int
 * @param incrColSok Nouvelle colonne sur laquelle Sokoban va se déplacer de type int
 * @param doubleIncrLigSok Ligne qui se trouve 2 ligne plus loin d'où va sokoban de type int
 * @param doubleIncrColSok Ligne qui se trouve 2 colonne plus loin d'où va sokoban de type int
 * @param nbDepla Nombre de déplacements déjà effectués de type int
 */
void deplacement_caisse_cible(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int doubleIncrLigSok,
    int doubleIncrColSok, int *nbDepla);

/**
 * @brief Procédure qui permet de déplacer Sokoban vers une cible
 * @param plateau Plateau du jeu de type t_Plateau
 * @param ligSok Ligne où se trouve Sokoban de type int
 * @param colSok Colonne où se trouve Sokoban de type int
 * @param incrLigSok Nouvelle ligne sur laquelle Sokoban va se déplacer de type int
 * @param incrColSok Nouvelle colonne sur laquelle Sokoban va se déplacer de type int
 * @param nbDepla Nombre de déplacements déjà effectués de type int
 */
void deplacement_cible(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int *nbDepla);

/**
 * @brief Fonction qui renvoie si le joueur a gagné
 * @param plateauDeJeu Plateau du jeu de type t_Plateau
 * @return true si le joueur a gagné sinon False
 */
bool gagne(t_Plateau plateauDeJeu);


int kbhit();

int main(){
    t_Plateau plateauDeJeu; // Plateau du jeu
    char nomFichier[TAILLE_FICHIER], touche=ATTENTE; // Nom du fichier + touche
    int nbDeplacements=ZERO, ligneSokoban, colonneSokoban; 
    printf("Entrez le nom du fichier : ");
    scanf("%s", nomFichier);
    charger_partie(plateauDeJeu, nomFichier);
    affichier_entete(nbDeplacements,nomFichier);
    afficher_plateau(plateauDeJeu);
    // Définition des coordonnées où se trouve Sokoban
    for (int i=0 ; i<NB_LIGNES ; i++) {
        for(int j=0;j<NB_COLONNES;j++) {
            if(plateauDeJeu[i][j]==SOKOBAN) {
                ligneSokoban=i;
                colonneSokoban=j;
            }
        }
    }
    jeu(&touche, plateauDeJeu, nomFichier, ligneSokoban,
        colonneSokoban, nbDeplacements);
    // Dit si le joueur a gagné ou abandonné en fonction de la dernirèe touche
    if(touche == ARRETER) {
        abandon(plateauDeJeu);
        printf("\nLa partie a été abandonnée\n");
    } else {
        printf("\nVous avez gagné !\n");
    }
    return EXIT_SUCCESS;
}

void jeu(char *toucheAppuyee, t_Plateau plateau, char fichier[],
    int ligSok, int colSok, int nbDepla){
    
    // Boucle du jeu qui se termine si le joueur gagne ou abandonne
    while (*toucheAppuyee != ARRETER && !gagne(plateau)) {
        *toucheAppuyee = ATTENTE;
        while (kbhit() == 0) {}
        *toucheAppuyee = getchar();
        if (*toucheAppuyee == RECOMMENCER) {
            recommencer(&nbDepla, plateau, fichier, &ligSok, &colSok);
        }
        deplacer(plateau, &ligSok, &colSok, *toucheAppuyee, &nbDepla);
        system("clear");
        affichier_entete(nbDepla, fichier);
        afficher_plateau(plateau);
    }
}

void afficher_plateau(t_Plateau plateau){
    for(int i = ZERO ; i < TAILLE ; i++) {
        for(int j = ZERO ; j < TAILLE ; j++){
            if(plateau[i][j] == SOKOBAN_CIBLE) {
                printf("%c", SOKOBAN);
            } else if (plateau[i][j] == CAISSE_CIBLE) {
                printf("%c", CAISSE);
            } else {
                printf("%c", plateau[i][j]);
            }
        }
        printf("\n");
    }
}

void affichier_entete(int nbDepla, char nomFich[]){
    // Affiche tous les éléments de l'en-tête
    printf("\nPartie : %s     Nombre de déplacements : %d\n\n",
        nomFich, nbDepla);
    printf("Actions disponibles :\n");
    printf("'z' = Aller en haut\n");
    printf("'s' = Aller en bas\n");
    printf("'q' = Aller à gauche\n");
    printf("'d' = Aller à droite\n");
    printf("'x' = Abandonner\n");
    printf("'r' = Recommencer la partie\n\n");
}

void deplacer(t_Plateau plateau, int *ligSok, int *colSok,
    char deplacement, int *nbDepla){

    int incrLigSok=ZERO, incrColSok=ZERO, doubleIncrLigSok=ZERO,
    doubleIncrColSok=ZERO;
    // incrLigSok et incrColSok changent en fonction de la direction choisie
    if(deplacement == HAUT) {
        incrLigSok = ENLEVER;
    } else if (deplacement == BAS) {
        incrLigSok = AJOUTER;
    } else if (deplacement == GAUCHE) {
        incrColSok = ENLEVER;
    } else if (deplacement == DROITE) {
        incrColSok = AJOUTER;
    }
    // doubleIncrLigSok et doubleIncrColSok représentent la ligne/colonne plus loin
    doubleIncrLigSok = incrLigSok * DOUBLE;
    doubleIncrColSok = incrColSok * DOUBLE;
    // Le déplacement se fait en fonction du cas dans lequel le joueur se trouve
    if(plateau[*ligSok+incrLigSok][*colSok+incrColSok] == RIEN){
        deplacement_rien(plateau, &*ligSok, &*colSok, incrLigSok,
            incrColSok, &*nbDepla);
    } else if (plateau[*ligSok+incrLigSok][*colSok+incrColSok] == CAISSE) {
        deplacement_caisse(plateau, &*ligSok, &*colSok, incrLigSok,
            incrColSok, doubleIncrLigSok, doubleIncrColSok, &*nbDepla);
    } else if (plateau[*ligSok+incrLigSok][*colSok+incrColSok]
        == CAISSE_CIBLE) {
        deplacement_caisse_cible(plateau, &*ligSok, &*colSok, incrLigSok,
            incrColSok, doubleIncrLigSok, doubleIncrColSok, &*nbDepla);
    } else if (plateau[*ligSok+incrLigSok][*colSok+incrColSok] == CIBLE) {
        deplacement_cible(plateau, &*ligSok, &*colSok, incrLigSok,
            incrColSok, &*nbDepla);
    }
}

void deplacement_rien(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int *nbDepla){

    // Si Sokoban se trouve sur une cible
    if (plateau[*ligSok][*colSok] == SOKOBAN_CIBLE){
        plateau[*ligSok][*colSok] = CIBLE;
        plateau[*ligSok+incrLigSok][*colSok+incrColSok] = SOKOBAN;
        deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
            &*colSok, &*nbDepla);
    } else {
        plateau[*ligSok][*colSok] = RIEN;
        plateau[*ligSok+incrLigSok][*colSok+incrColSok] = SOKOBAN;
        deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
            &*colSok, &*nbDepla);
    }
}

void deplacement_caisse(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int doubleIncrLigSok,
    int doubleIncrColSok, int *nbDepla){
    
    // Si 2 cases plus loin il ne se trouve rien
    if (plateau[*ligSok+doubleIncrLigSok][*colSok+doubleIncrColSok] == RIEN){
        // Si Sokoban se trouve sur une cible
        if (plateau[*ligSok][*colSok] == SOKOBAN_CIBLE){
            plateau[*ligSok+doubleIncrLigSok]
            [*colSok+doubleIncrColSok] = CAISSE;

            plateau[*ligSok+incrLigSok][*colSok+incrColSok] = SOKOBAN;
            plateau[*ligSok][*colSok] = CIBLE;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        } else {
            plateau[*ligSok+doubleIncrLigSok]
            [*colSok+doubleIncrColSok] = CAISSE;

            plateau[*ligSok+incrLigSok][*colSok+incrColSok] = SOKOBAN;
            plateau[*ligSok][*colSok] = RIEN;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        }
    // Sinon si 2 cases plus loin il se trouve une cible
    } else if (plateau[*ligSok+doubleIncrLigSok]
        [*colSok+doubleIncrColSok] == CIBLE) {

        // Si Sokoban se trouve sur une cible
        if (plateau[*ligSok][*colSok] == SOKOBAN_CIBLE){
            plateau[*ligSok+doubleIncrLigSok]
            [*colSok+doubleIncrColSok] = CAISSE_CIBLE;

            plateau[*ligSok+incrLigSok][*colSok+incrColSok] = SOKOBAN;
            plateau[*ligSok][*colSok] = CIBLE;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        } else {
            plateau[*ligSok+doubleIncrLigSok]
            [*colSok+doubleIncrColSok] = CAISSE_CIBLE;

            plateau[*ligSok+incrLigSok][*colSok+incrColSok] = SOKOBAN;
            plateau[*ligSok][*colSok] = RIEN;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        }
    }
}

void deplacement_caisse_cible(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int doubleIncrLigSok,
    int doubleIncrColSok, int *nbDepla){

    // Si 2 cases plus loin il ne se trouve rien
    if (plateau[*ligSok+doubleIncrLigSok][*colSok+doubleIncrColSok] == RIEN){
        // Si Sokoban se trouve sur une cible
        if (plateau[*ligSok][*colSok]==SOKOBAN_CIBLE){
            plateau[*ligSok+doubleIncrLigSok]
            [*colSok+doubleIncrColSok] = CAISSE;

            plateau[*ligSok+incrLigSok][*colSok+incrColSok] = SOKOBAN_CIBLE;
            plateau[*ligSok][*colSok] = CIBLE;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        } else {
            plateau[*ligSok+doubleIncrLigSok]
            [*colSok+doubleIncrColSok] = CAISSE;
            plateau[*ligSok+incrLigSok][*colSok+incrColSok] = SOKOBAN_CIBLE;
            plateau[*ligSok][*colSok] = RIEN;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        }
    // Sinon si 2 cases plus loin il se trouve une cible
    } else if (plateau[*ligSok+doubleIncrLigSok]
        [*colSok+doubleIncrColSok] == CIBLE) {
        // Si Sokoban se trouve sur une cible
        if (plateau[*ligSok][*colSok] == SOKOBAN_CIBLE){
            plateau[*ligSok+doubleIncrLigSok]
            [*colSok+doubleIncrColSok] = CAISSE_CIBLE;

            plateau[*ligSok+incrLigSok][*colSok+incrColSok] = SOKOBAN_CIBLE;
            plateau[*ligSok][*colSok] = CIBLE;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        } else {
            plateau[*ligSok+doubleIncrLigSok]
            [*colSok+doubleIncrColSok] = CAISSE_CIBLE;

            plateau[*ligSok+incrLigSok][*colSok+incrColSok] = SOKOBAN_CIBLE;
            plateau[*ligSok][*colSok] = RIEN;
            deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
                &*colSok, &*nbDepla);
        }
    }
}

void deplacement_cible(t_Plateau plateau, int *ligSok, int *colSok,
    int incrLigSok, int incrColSok, int *nbDepla){

    // Si Sokoban se trouve sur une cible
    if (plateau[*ligSok][*colSok] == SOKOBAN_CIBLE){
        plateau[*ligSok][*colSok] = CIBLE;
        plateau[*ligSok+incrLigSok][*colSok+incrColSok] = SOKOBAN_CIBLE;
        deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
            &*colSok, &*nbDepla);
    } else {
        plateau[*ligSok][*colSok] = RIEN;
        plateau[*ligSok+incrLigSok][*colSok+incrColSok] = SOKOBAN_CIBLE;
        deplacement_sokoban(incrLigSok, incrColSok, &*ligSok,
            &*colSok, &*nbDepla);
    }
}

void deplacement_sokoban(int nvLig, int nvCol, int *ligSok,
    int *colSok, int *nbDepla){
    
    // Effectue les changements dans les coordonnées de Sokoban
    *ligSok = *ligSok + nvLig;
    *colSok= *colSok + nvCol;
    *nbDepla= *nbDepla + 1;
}

void recommencer(int *nbDepla, t_Plateau plateauDeJeu, char nomFichier[],
    int *ligneSokoban, int *colonneSokoban){

    char choix;
    printf("Êtes-vous sûr de vouloir recommencer ? (O/N) ");
    scanf("%c", &choix);
    // Regarde si le joueur a choisi de valider de recommencer
    if (choix == VALIDATION) {
        charger_partie(plateauDeJeu, nomFichier);
        *nbDepla=0;
        for (int i=0 ; i<NB_LIGNES ; i++) {
            for (int j=0 ; j<NB_COLONNES ; j++) {
                if (plateauDeJeu[i][j] == SOKOBAN){
                    *ligneSokoban = i;
                    *colonneSokoban = j;
                }
            }
        }
    }
}

void abandon(t_Plateau plateauDeJeu){
    char choix, nomNvFichier[TAILLE_FICHIER];
    printf("Souhaitez-vous enregistrer la partie ? (O/N) ");
    scanf("%c", &choix);
    // Regarde si le joueur a choisi de sauvegarder
    if (choix == VALIDATION){
        printf("Quel nom au fichier ? (15 caractères maximum) ");
        scanf("%s", nomNvFichier);
        enregistrer_partie(plateauDeJeu, nomNvFichier);
    }
}

bool gagne(t_Plateau plateauDeJeu){
    bool victoire = true;
    // Regarde si il reste des caisses ou Sokoban sur une cible
    for (int i=0 ; i<NB_LIGNES ; i++){
        for (int j=0 ; j<NB_COLONNES ; j++){
            if (plateauDeJeu[i][j] == CAISSE
                || plateauDeJeu[i][j] == SOKOBAN_CIBLE){
                victoire = false;
            }
        }
    }
    return victoire;
}


void charger_partie(t_Plateau plateau, char fichier[]){
    FILE * f;
    char finDeLigne;

    f = fopen(fichier, "r");
    if (f==NULL){
        printf("ERREUR SUR FICHIER");
        exit(EXIT_FAILURE);
    } else {
        for (int ligne=0 ; ligne<TAILLE ; ligne++){
            for (int colonne=0 ; colonne<TAILLE ; colonne++){
                fread(&plateau[ligne][colonne], sizeof(char), 1, f);
            }
            fread(&finDeLigne, sizeof(char), 1, f);
        }
        fclose(f);
    }
}



void enregistrer_partie(t_Plateau plateau, char fichier[]){
    FILE * f;
    char finDeLigne='\n';

    f = fopen(fichier, "w");
    for (int ligne=0 ; ligne<TAILLE ; ligne++){
        for (int colonne=0 ; colonne<TAILLE ; colonne++){
            fwrite(&plateau[ligne][colonne], sizeof(char), 1, f);
        }
        fwrite(&finDeLigne, sizeof(char), 1, f);
    }
    fclose(f);
}


int kbhit(){
	// la fonction retourne :
	// 1 si un caractere est present
	// 0 si pas de caractere présent
	int unCaractere=0;
	struct termios oldt, newt;
	int ch;
	int oldf;

	// mettre le terminal en mode non bloquant
	tcgetattr(STDIN_FILENO, &oldt);
	newt = oldt;
	newt.c_lflag &= ~(ICANON | ECHO);
	tcsetattr(STDIN_FILENO, TCSANOW, &newt);
	oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
	fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
 
	ch = getchar();

	// restaurer le mode du terminal
	tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
	fcntl(STDIN_FILENO, F_SETFL, oldf);
 
	if(ch != EOF){
		ungetc(ch, stdin);
		unCaractere=1;
	} 
	return unCaractere;
}